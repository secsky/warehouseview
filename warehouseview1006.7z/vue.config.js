// vue.config.js

/**
 * @type {import('@vue/cli-service').ProjectOptions}
 */
 module.exports = {
    lintOnSave: false,
    devServer:{
      proxy:'http://192.168.2.6:80'
    },
  }