import Vue from 'vue'
import App from './App.vue'
import axios from 'axios'
import VueAxios from 'vue-axios'
import VueRouter from 'vue-router'
import KW from "./components/KW.vue";
import Welcome from "./components/Welcome.vue";
// import Antd from 'ant-design-vue'
import 'ant-design-vue/dist/antd.css'
import {Drawer,Modal,Table,Tag,Input,Badge,ConfigProvider,Breadcrumb} from 'ant-design-vue'
Vue.use(VueRouter)
Vue.use(Drawer).use(Modal).use(Table).use(Tag).use(Input).use(Badge).use(ConfigProvider).use(Breadcrumb)
Vue.use(VueAxios, axios);
Vue.config.productionTip = false;
const routes = [
  { path: '/kw', component: KW },
  { path: '/', component: Welcome }
]
const router = new VueRouter({
  routes // (缩写) 相当于 routes: routes
})
new Vue({
  router,
  render: h => h(App),
}).$mount('#app');
