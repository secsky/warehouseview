<template>
  <div>
      <Top title="欢迎来到系统!" version="Beta Version" />
  </div>
</template>

<script>
import Top from "./Top.vue";
export default {
    components:{
        Top
    }
}
</script>

<style>

</style>