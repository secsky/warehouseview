<template>
  <a-breadcrumb>
    <a-breadcrumb-item><router-link to="/">首页</router-link></a-breadcrumb-item>
    <a-breadcrumb-item><router-link to="/foo">foo</router-link></a-breadcrumb-item>
    <a-breadcrumb-item><router-link to="/bar">bar</router-link></a-breadcrumb-item>
    <a-breadcrumb-item><router-link to="/kw">库位图</router-link></a-breadcrumb-item>
  </a-breadcrumb>
</template>
