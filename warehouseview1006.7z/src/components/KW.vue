<template>
  <div>
    <Top title="BOM库目视图" version="beta1.2" />
    <SearchBar />
    <Center />
    <SideBar />
  </div>
</template>

<script>
import Top from "./Top.vue";
import SearchBar from "./SearchBar.vue";
import Center from "./Center.vue";
import SideBar from "./SideBar.vue";
export default {
  name: "KW",
  components: {
    SearchBar,
    Center,
    SideBar,
    Top,
  },
};
</script>

<style>
</style>